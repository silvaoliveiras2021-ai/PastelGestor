import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await LocalStore.instance.database;
  runApp(const PastelGestorApp());
}

const orange = Color(0xFFE87524);
const navy = Color(0xFF233044);
const cream = Color(0xFFFFF8F0);
const muted = Color(0xFF758092);
const green = Color(0xFF23845B);

class LocalStore {
  LocalStore._();
  static final instance = LocalStore._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), 'pastelgestor.db');
    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            price_cents INTEGER NOT NULL,
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE ingredients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            unit TEXT NOT NULL,
            quantity_milli INTEGER NOT NULL,
            purchase_cents INTEGER NOT NULL,
            created_at TEXT NOT NULL
          )
        ''');
      },
    );
    return _db!;
  }

  Future<List<Map<String, Object?>>> products() async =>
      (await database).query('products', orderBy: 'name COLLATE NOCASE');

  Future<void> addProduct({
    required String name,
    required String category,
    required int priceCents,
  }) async {
    await (await database).insert('products', {
      'name': name.trim(),
      'category': category,
      'price_cents': priceCents,
      'active': 1,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  Future<void> setProductActive(int id, bool active) async {
    await (await database).update(
      'products', {'active': active ? 1 : 0},
      where: 'id = ?', whereArgs: [id],
    );
  }

  Future<List<Map<String, Object?>>> ingredients() async =>
      (await database).query('ingredients', orderBy: 'name COLLATE NOCASE');

  Future<void> addIngredient({
    required String name,
    required String unit,
    required int quantityMilli,
    required int purchaseCents,
  }) async {
    await (await database).insert('ingredients', {
      'name': name.trim(),
      'unit': unit,
      'quantity_milli': quantityMilli,
      'purchase_cents': purchaseCents,
      'created_at': DateTime.now().toIso8601String(),
    });
  }
}

String money(int cents) =>
    'R\$ ${(cents ~/ 100)},${(cents % 100).toString().padLeft(2, '0')}';

class PastelGestorApp extends StatelessWidget {
  const PastelGestorApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'PastelGestor',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: cream,
      colorScheme: ColorScheme.fromSeed(seedColor: orange, surface: cream),
      appBarTheme: const AppBarTheme(backgroundColor: cream, foregroundColor: navy, elevation: 0),
      cardTheme: CardTheme(
        color: Colors.white,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)),
      ),
    ),
    home: const MainShell(),
  );
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  final pages = const [Dashboard(), ProductsScreen(), IngredientsScreen(), PlaceholderScreen(title: 'Financeiro', icon: Icons.account_balance_wallet_outlined), PlaceholderScreen(title: 'Relatórios', icon: Icons.bar_chart_rounded)];
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Row(children: [
        Container(width: 38, height: 38, decoration: BoxDecoration(color: orange, borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.storefront_rounded, color: Colors.white)),
        const SizedBox(width: 10),
        const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('PastelGestor', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
          Text('GESTÃO SIMPLES, NEGÓCIO FORTE', style: TextStyle(fontSize: 9, color: muted, letterSpacing: .8)),
        ]),
      ]),
    ),
    body: IndexedStack(index: index, children: pages),
    bottomNavigationBar: NavigationBar(
      selectedIndex: index,
      onDestinationSelected: (v) => setState(() => index = v),
      backgroundColor: Colors.white,
      indicatorColor: orange.withOpacity(.13),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'Início'),
        NavigationDestination(icon: Icon(Icons.lunch_dining_rounded), label: 'Produtos'),
        NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'Insumos'),
        NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), label: 'Financeiro'),
        NavigationDestination(icon: Icon(Icons.bar_chart_rounded), label: 'Relatórios'),
      ],
    ),
  );
}

class Dashboard extends StatelessWidget {
  const Dashboard({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Olá! 👋', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: navy)),
    const Text('Sua pastelaria em um só lugar.', style: TextStyle(color: muted)),
    const SizedBox(height: 18),
    Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(gradient: const LinearGradient(colors: [orange, Color(0xFFF29B43)]), borderRadius: BorderRadius.circular(22)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('FATURAMENTO DE HOJE', style: TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1)),
      SizedBox(height: 8), Text('R\$ 0,00', style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w900)),
      SizedBox(height: 6), Text('Comece registrando suas vendas.', style: TextStyle(color: Colors.white)),
    ])),
    const SizedBox(height: 14),
    const Row(children: [Expanded(child: Metric(title: 'Vendas', value: '0', icon: Icons.receipt_long)), SizedBox(width: 10), Expanded(child: Metric(title: 'Despesas', value: 'R\$ 0,00', icon: Icons.payments_outlined))]),
    const SizedBox(height: 10),
    const Row(children: [Expanded(child: Metric(title: 'Produtos', value: '—', icon: Icons.lunch_dining)), SizedBox(width: 10), Expanded(child: Metric(title: 'Alertas', value: '—', icon: Icons.notifications_active_outlined))]),
    const SizedBox(height: 20),
    const Text('PRÓXIMOS PASSOS', style: TextStyle(color: muted, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1)),
    const SizedBox(height: 8),
    const InfoTile(icon: Icons.add_box_outlined, title: 'Cadastre seus produtos', detail: 'Inclua pastéis, bebidas e outros itens do cardápio.'),
    const InfoTile(icon: Icons.scale_outlined, title: 'Cadastre seus ingredientes', detail: 'Depois, associe os insumos às receitas e acompanhe os custos.'),
  ]);
}

class Metric extends StatelessWidget {
  final String title, value; final IconData icon;
  const Metric({super.key, required this.title, required this.value, required this.icon});
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Icon(icon, color: orange), const SizedBox(height: 10),
    Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 19, color: navy)),
    Text(title, style: const TextStyle(color: muted, fontSize: 12)),
  ])));
}

class InfoTile extends StatelessWidget {
  final IconData icon; final String title, detail;
  const InfoTile({super.key, required this.icon, required this.title, required this.detail});
  @override
  Widget build(BuildContext context) => Card(child: ListTile(leading: CircleAvatar(backgroundColor: orange.withOpacity(.12), child: Icon(icon, color: orange)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, color: navy)), subtitle: Text(detail, style: const TextStyle(color: muted))));
}

class ProductsScreen extends StatefulWidget {
  const ProductsScreen({super.key});
  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  List<Map<String, Object?>> rows = [];
  bool loading = true;
  @override
  void initState() { super.initState(); refresh(); }
  Future<void> refresh() async {
    final data = await LocalStore.instance.products();
    if (!mounted) return;
    setState(() { rows = data; loading = false; });
  }
  Future<void> add() async {
    final saved = await showDialog<bool>(context: context, builder: (_) => const ProductDialog());
    if (saved == true) refresh();
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: cream,
    floatingActionButton: FloatingActionButton.extended(onPressed: add, backgroundColor: orange, foregroundColor: Colors.white, icon: const Icon(Icons.add), label: const Text('Novo produto')),
    body: loading ? const Center(child: CircularProgressIndicator()) : rows.isEmpty
      ? EmptyState(icon: Icons.lunch_dining_rounded, title: 'Nenhum produto cadastrado', detail: 'Comece adicionando os itens do seu cardápio.')
      : ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 90), children: [
          Text('${rows.length} produto(s) cadastrado(s)', style: const TextStyle(color: muted)),
          const SizedBox(height: 8),
          ...rows.map((r) => Card(child: ListTile(
            leading: CircleAvatar(backgroundColor: orange.withOpacity(.12), child: const Icon(Icons.lunch_dining, color: orange)),
            title: Text(r['name'] as String, style: const TextStyle(fontWeight: FontWeight.bold, color: navy)),
            subtitle: Text('${r['category']} • ${(r['active'] as int) == 1 ? 'Ativo' : 'Inativo'}'),
            trailing: Text(money(r['price_cents'] as int), style: const TextStyle(fontWeight: FontWeight.w900, color: navy)),
            onTap: () async {
              await LocalStore.instance.setProductActive(r['id'] as int, (r['active'] as int) != 1);
              refresh();
            },
          ))),
          const Padding(padding: EdgeInsets.only(top: 8), child: Text('Toque em um produto para alternar entre ativo e inativo.', style: TextStyle(color: muted, fontSize: 11))),
        ]),
  );
}

class ProductDialog extends StatefulWidget {
  const ProductDialog({super.key});
  @override
  State<ProductDialog> createState() => _ProductDialogState();
}

class _ProductDialogState extends State<ProductDialog> {
  final name = TextEditingController();
  final price = TextEditingController();
  String category = 'Pastéis';
  String? error;
  @override
  void dispose() { name.dispose(); price.dispose(); super.dispose(); }
  int? parseCents(String value) {
    final normalized = value.trim().replaceAll('.', '').replaceAll(',', '.');
    final parsed = double.tryParse(normalized);
    if (parsed == null || parsed <= 0) return null;
    return (parsed * 100).round();
  }
  Future<void> save() async {
    final n = name.text.trim();
    final cents = parseCents(price.text);
    if (n.isEmpty || cents == null) { setState(() => error = 'Informe o nome e um preço válido maior que zero.'); return; }
    await LocalStore.instance.addProduct(name: n, category: category, priceCents: cents);
    if (mounted) Navigator.pop(context, true);
  }
  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('Novo produto', style: TextStyle(fontWeight: FontWeight.w900, color: navy)),
    content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
      TextField(controller: name, autofocus: true, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Nome do produto', hintText: 'Ex.: Pastel de carne')),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(value: category, decoration: const InputDecoration(labelText: 'Categoria'), items: const ['Pastéis', 'Bebidas', 'Porções', 'Combos', 'Outros'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => setState(() => category = v ?? 'Outros')),
      const SizedBox(height: 12),
      TextField(controller: price, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Preço de venda', prefixText: 'R\$ ', hintText: '10,00')),
      if (error != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(error!, style: const TextStyle(color: Colors.red, fontSize: 12))),
    ])),
    actions: [
      TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
      FilledButton(onPressed: save, style: FilledButton.styleFrom(backgroundColor: orange), child: const Text('Salvar')),
    ],
  );
}

class IngredientsScreen extends StatefulWidget {
  const IngredientsScreen({super.key});
  @override
  State<IngredientsScreen> createState() => _IngredientsScreenState();
}
class _IngredientsScreenState extends State<IngredientsScreen> {
  List<Map<String, Object?>> rows = [];
  bool loading = true;
  @override
  void initState() { super.initState(); refresh(); }
  Future<void> refresh() async {
    final data = await LocalStore.instance.ingredients();
    if (!mounted) return;
    setState(() { rows = data; loading = false; });
  }
  Future<void> add() async {
    final ok = await showDialog<bool>(context: context, builder: (_) => const IngredientDialog());
    if (ok == true) refresh();
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: cream,
    floatingActionButton: FloatingActionButton.extended(onPressed: add, backgroundColor: orange, foregroundColor: Colors.white, icon: const Icon(Icons.add), label: const Text('Novo ingrediente')),
    body: loading ? const Center(child: CircularProgressIndicator()) : rows.isEmpty
      ? const EmptyState(icon: Icons.scale_outlined, title: 'Nenhum ingrediente cadastrado', detail: 'Cadastre farinha, carne, queijo, óleo e outros insumos.')
      : ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 90), children: [
          Text('${rows.length} ingrediente(s) cadastrado(s)', style: const TextStyle(color: muted)),
          const SizedBox(height: 8),
          ...rows.map((r) => Card(child: ListTile(
            leading: CircleAvatar(backgroundColor: green.withOpacity(.12), child: const Icon(Icons.inventory_2_outlined, color: green)),
            title: Text(r['name'] as String, style: const TextStyle(fontWeight: FontWeight.bold, color: navy)),
            subtitle: Text('Unidade: ${r['unit']}'),
            trailing: Text(money(r['purchase_cents'] as int), style: const TextStyle(fontWeight: FontWeight.w900, color: navy)),
          ))),
        ]),
  );
}

class IngredientDialog extends StatefulWidget {
  const IngredientDialog({super.key});
  @override
  State<IngredientDialog> createState() => _IngredientDialogState();
}
class _IngredientDialogState extends State<IngredientDialog> {
  final name = TextEditingController(), quantity = TextEditingController(), cost = TextEditingController();
  String unit = 'kg'; String? error;
  @override
  void dispose() { name.dispose(); quantity.dispose(); cost.dispose(); super.dispose(); }
  double? number(String s) => double.tryParse(s.trim().replaceAll('.', '').replaceAll(',', '.'));
  Future<void> save() async {
    final q = number(quantity.text), c = number(cost.text);
    if (name.text.trim().isEmpty || q == null || q <= 0 || c == null || c <= 0) {
      setState(() => error = 'Preencha nome, quantidade e preço de compra válidos.'); return;
    }
    await LocalStore.instance.addIngredient(name: name.text, unit: unit, quantityMilli: (q * 1000).round(), purchaseCents: (c * 100).round());
    if (mounted) Navigator.pop(context, true);
  }
  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('Novo ingrediente', style: TextStyle(fontWeight: FontWeight.w900, color: navy)),
    content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
      TextField(controller: name, autofocus: true, decoration: const InputDecoration(labelText: 'Nome', hintText: 'Ex.: Queijo muçarela')),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(child: TextField(controller: quantity, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Quantidade comprada'))),
        const SizedBox(width: 10),
        SizedBox(width: 95, child: DropdownButtonFormField<String>(value: unit, decoration: const InputDecoration(labelText: 'Unidade'), items: const ['kg', 'g', 'L', 'ml', 'un'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => setState(() => unit = v ?? 'kg'))),
      ]),
      const SizedBox(height: 10),
      TextField(controller: cost, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Preço total da compra', prefixText: 'R\$ ', hintText: '35,00')),
      if (error != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(error!, style: const TextStyle(color: Colors.red, fontSize: 12))),
    ])),
    actions: [
      TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
      FilledButton(onPressed: save, style: FilledButton.styleFrom(backgroundColor: orange), child: const Text('Salvar')),
    ],
  );
}

class EmptyState extends StatelessWidget {
  final IconData icon; final String title, detail;
  const EmptyState({super.key, required this.icon, required this.title, required this.detail});
  @override
  Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(30), child: Column(mainAxisSize: MainAxisSize.min, children: [
    CircleAvatar(radius: 34, backgroundColor: orange.withOpacity(.12), child: Icon(icon, color: orange, size: 32)),
    const SizedBox(height: 16), Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: navy)),
    const SizedBox(height: 6), Text(detail, textAlign: TextAlign.center, style: const TextStyle(color: muted)),
  ])));
}

class PlaceholderScreen extends StatelessWidget {
  final String title; final IconData icon;
  const PlaceholderScreen({super.key, required this.title, required this.icon});
  @override
  Widget build(BuildContext context) => EmptyState(icon: icon, title: '$title em desenvolvimento', detail: 'Este módulo será conectado aos cadastros e às movimentações nas próximas etapas.');
}
