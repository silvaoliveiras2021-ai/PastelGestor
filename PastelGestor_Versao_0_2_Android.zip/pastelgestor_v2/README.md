# PastelGestor — versão 0.2.0

## Nesta versão
- Navegação Android em Flutter.
- Banco SQLite local.
- Cadastro simples de produtos: nome, categoria e preço.
- Ativar/desativar produto tocando no item.
- Cadastro inicial de ingredientes: nome, unidade, quantidade comprada e custo total.
- Dados persistem no aparelho e funcionam sem internet.

## Ainda não implementado
- Fichas técnicas e consumo automático de ingredientes.
- Vendas, caixa e relatórios reais.
- Login, nuvem, backup e sincronização.
- Edição e exclusão de cadastros.
- Fotos de produtos.

## Executar
Requer Flutter SDK e Android SDK:
1. `flutter pub get`
2. `flutter run`
3. `flutter build apk --debug`

Os valores inseridos são armazenados localmente no SQLite do aparelho. Esta versão ainda não oferece backup na nuvem; não use como único registro comercial até a implementação do backup e dos testes.
